from tupy import Image

class You_Died(Image):
    def __init__(self) -> None:
        self._x = 450
        self._y = 205
        self._file = "../Img/You_died.png"